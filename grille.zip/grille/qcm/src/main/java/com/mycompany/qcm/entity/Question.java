package com.mycompany.qcm.entity;

public class Question {
    private int idQuestion;
    private String libelle;
    private  Grille_Question grille_question;
    private Response response;

    public int getIdQuestion() {
        return idQuestion;
    }

    public void setIdQuestion(int idQuestion) {
        this.idQuestion = idQuestion;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public Grille_Question getGrille_question() {
        return grille_question;
    }

    public void setGrille_question(Grille_Question grille_question) {
        this.grille_question = grille_question;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }
}
