package com.mycompany.qcm.repository;
import com.mycompany.qcm.DataSourceProvider;
import com.mycompany.qcm.HibernateUtil;
import com.mycompany.qcm.entity.Type_User;
import  org.hibernate.Session;
import org.hibernate.Transaction;

import javax.sql.DataSource;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class Type_UserRepositoryImpl {

    public void create (Type_User type_user){
        Session session=null;
        Transaction tx=null;
        try {
            session= HibernateUtil.getSessionFactory().openSession();
            tx=session.beginTransaction();
            session.persist(type_user);
            tx.commit();

        System.out.println("role crée");

        }catch (Exception e) {
            if (tx != null) {
                tx.rollback();

            }
            e.printStackTrace();
        }
        finally {
            if (session!=null){
                session.close();
            }
        }
    }
    public void delete (int id){

        Type_User type_user=getById(id);


        Session session=HibernateUtil.getSessionFactory().getCurrentSession();

        session.delete(type_user);
        System.out.println("role supprimer");

    }
    public Type_User getById (int idType_User){
        Type_User type_user=null;
        Session session=null;

        session= HibernateUtil.getSessionFactory().getCurrentSession();
        type_user=session.get(Type_User.class,idType_User);
        System.out.println("Role lu");

        return type_user;
    }
    public List<Type_User> List(){
        Connection conn = null;
        List<Type_User> type_users =new ArrayList<>();
        try {

            DataSource dataSource= DataSourceProvider.getSingleDataSourceInstance();

            conn= dataSource.getConnection();

            PreparedStatement preparedStatement= conn.prepareStatement("SELECT  ID, NOM , PRENOM, SEXE FROM JOUEUR ");


            ResultSet rs=preparedStatement.executeQuery();

            while (rs.next()){

                Type_User type_user =new Type_User();
                type_user.setIdType_User(rs.getInt("idTupe_User"));
                type_user.setRole(rs.getString("Role"));

                type_users.add(type_user);
            }


            System.out.println("La liste des joueurs");
        } catch (SQLException e) {
            e.printStackTrace();
            try {
                if (conn!=null)conn.rollback();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        finally {
            try {
                if (conn!=null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return type_users;
    }
}
