package com.mycompany.qcm.entity;

public class Grille_Question {
    private int idGrille_Question;
    private  String question;

    public int getIdGrille_Question() {
        return idGrille_Question;
    }

    public void setIdGrille_Question(int idGrille_Question) {
        this.idGrille_Question = idGrille_Question;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
