package com.mycompany.qcm.service;

import com.mycompany.qcm.HibernateUtil;
import com.mycompany.qcm.entity.Type_User;
import com.mycompany.qcm.repository.Type_UserRepositoryImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;
public class Type_UserService {
    private Type_UserRepositoryImpl type_userRepository;

    public Type_UserService(){
        this.type_userRepository=new Type_UserRepositoryImpl();
    }

    public  void createRole(Type_User type_user){
        Session session=null;
        Transaction tx=null;
        try {
            session= HibernateUtil.getSessionFactory().getCurrentSession();
            tx=session.beginTransaction();
            type_userRepository.create(type_user);
            tx.commit();

        }catch (Exception e) {
            if (tx != null) {
                tx.rollback();

            }
            e.printStackTrace();
        }
        finally {
            if (session!=null){
                session.close();
            }
        }
    }

    public Type_User getType_User(int idType_User){
        Session session=null;
        Transaction tx=null;
       Type_User type_user=null;
        try {
            session= HibernateUtil.getSessionFactory().getCurrentSession();
            tx=session.beginTransaction();
            type_user=type_userRepository.getById(idType_User);
            tx.commit();

        }catch (Exception e) {
            if (tx != null) {
                tx.rollback();

            }
            e.printStackTrace();
        }
        finally {
            if (session!=null){
                session.close();
            }
        }
        return type_user;
    }
    public  void deleteRole(int id){
        Session session=null;
        Transaction tx=null;
        try {
            session= HibernateUtil.getSessionFactory().getCurrentSession();
            tx=session.beginTransaction();
            type_userRepository.delete(id);
            tx.commit();
        }
        catch (Exception e){
            if (tx!=null){
                tx.rollback();
            }
            e.printStackTrace();
        }
        finally {
            if (session!=null){
                session.close();
            }
        }

    }
    public void renomme(int id, String nouveauRole){

        Type_User type_user=getType_User(id);

        Session session=null;
        Transaction tx=null;
        try {
            session= HibernateUtil.getSessionFactory().getCurrentSession();
            tx=session.beginTransaction();
            type_user.setRole(nouveauRole);
            Type_User type_user2=(Type_User) session.merge(type_user);
            tx.commit();

        }catch (Exception e) {
            if (tx != null) {
                tx.rollback();

            }
            e.printStackTrace();
        }
        finally {
            if (session!=null){
                session.close();
            }
        }
    }
    public void modifier(int id, String role){

        Type_User type_user=getType_User(id);

        Session session=null;
        Transaction tx=null;
        try {
            session= HibernateUtil.getSessionFactory().getCurrentSession();
            tx=session.beginTransaction();
            type_user.setRole(role);
            Type_User type_user1=(Type_User) session.merge(type_user);
            tx.commit();

        }catch (Exception e) {
            if (tx != null) {
                tx.rollback();

            }
            e.printStackTrace();
        }
        finally {
            if (session!=null){
                session.close();
            }
        }
    }
}
