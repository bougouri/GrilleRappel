package com.mycompany.qcm.entity;

public class Type_User {
    private int idType_User;
    private String role;

    public int getIdType_User() {
        return idType_User;
    }

    public void setIdType_User(int idType_User) {
        this.idType_User = idType_User;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
