package com.mycompany.qcm.entity;

public class Theme_has_Question {
    private  Theme theme;
    private  Question question;
    private Grille_Question grille_question;
    private Response response;

    public Theme getTheme() {
        return theme;
    }

    public void setTheme(Theme theme) {
        this.theme = theme;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public Grille_Question getGrille_question() {
        return grille_question;
    }

    public void setGrille_question(Grille_Question grille_question) {
        this.grille_question = grille_question;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }
}
