package com.mycompany.qcm;
import com.mycompany.qcm.Controller.Type_UserController;
public class IU {
    public  static  void  main(String... args){
        Type_UserController controller=new Type_UserController();
        controller.afficheDetailsType();
    }
}
