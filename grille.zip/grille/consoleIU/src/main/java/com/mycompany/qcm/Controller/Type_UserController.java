package com.mycompany.qcm.Controller;
import java.util.Scanner;

import com.mycompany.qcm.entity.Type_User;
import com.mycompany.qcm.service.Type_UserService;

public class Type_UserController {
    private Type_UserService type_userService;

    public Type_UserController() {
        this.type_userService = new Type_UserService();
    }

    public void afficheDetailsType() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel role   vous voulez affichez ?");
        int identifiant = scanner.nextInt();
        type_userService.getType_User(identifiant);
        Type_User type_user = type_userService.getType_User(identifiant);
        System.out.println("Le role  "+ type_user.getRole());
    }

    public void creerRole() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Veuillez entrez le nom du role");
        String role = scanner.nextLine();
        Type_User type_user = new Type_User();
        type_user.setRole(role);

        type_userService.createRole(type_user);
        System.out.println("le role à  été crée, son id est " + type_user.getIdType_User());

    }

    public void supprimeRole() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel est l'identifiant du role que vous voulez supprimer ?");
        int identifiant = scanner.nextInt();

        type_userService.deleteRole(identifiant);
    }

    public void renommeRole() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel est l'identifiant du role dont vous voulez renommer ?");
        int identifiant = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Quel est le nouveau role ?");
        String role = scanner.nextLine();
        type_userService.renomme(identifiant, role);

    }
    public void modifieRole() {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Quel est l'identifiant du role dont vous voulez modifier ?");
       int  identifiant = scanner.nextInt();
        scanner.nextLine();
        System.out.println(" le nouveau role) ");
        String role = scanner.nextLine();
        type_userService.modifier(identifiant, role);

    }
}
